USE [PTClinicDB]
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'BA35F284-2DE0-43AB-AC93-32299CC97795',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           338,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'A796CFD7-C5D1-473F-A6D6-ED421E1615D7',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           338,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'C745045C-4AE2-49E9-A3D1-5F07B9816B61',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           150,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '3CBE111F-5E33-47E4-90E0-7F0D6381D4DE',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           150,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '98ECB46A-68D6-4078-9C99-E69DB12DB908',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           65,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '463D51B0-ED57-412A-9E23-0BA89C577DC3',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           300,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'B3E9FC66-3018-4E16-BD0D-34CF63F174F2',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           90,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '9346FF24-8B15-45A9-9F60-17DF165D7954',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           150,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'F6FCFEAA-9818-417A-80C3-D18120115AD6',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           0,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '59C46D8D-1742-4907-BCFD-044AC339C4CB',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           50,
           GetDate(),
           NULL,
           0)
GO

INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           'FAA867F1-B4DA-40BC-8CC7-13DCFDA7F884',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           40,
           GetDate(),
           NULL,
           0)
GO


INSERT INTO [dbo].[CompanyServices]
           ([Id]
           ,[Service_Id]
           ,[Company_Id]
           ,[Price]
           ,[Create_Date]
           ,[Last_Modify_Date]
           ,[Is_Deleted])
     VALUES
           (NewID(),
           '3E0C0A95-03E2-49F0-88BF-D63820AFBB89',
           '34885036-8F0D-4CD1-A7D2-FF7780A038B4',
           0,
           GetDate(),
           NULL,
           0)
GO

